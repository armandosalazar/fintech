{
    "sProcessing":   "Pagproseso...",
    "sLengthMenu":   "Ipakita _MENU_ entries",
    "sZeroRecords":  "Walang katugmang  mga talaan  na natagpuan",
    "sInfo":         "Ipinapakita ang  _START_  sa _END_ ng _TOTAL_ entries",
    "sInfoEmpty":    "Ipinapakita ang 0-0 ng 0 entries",
    "sInfoFiltered": "(na-filter mula _MAX_ kabuuang entries)",
    "sInfoPostFix":  "",
    "sSearch":       "Paghahanap:",
    "sUrl":          "",
    "oPaginate": {
        "sFirst":    "Unang",
        "sPrevious": "Nakaraan",
        "sNext":     "Susunod",
        "sLast":     "Huli"
    }
}
